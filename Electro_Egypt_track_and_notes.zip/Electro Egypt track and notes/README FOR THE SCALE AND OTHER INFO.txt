Here's the scale I used for the track: D Arabian

With sharps on everything: 
D - D# - F# - G - A - A# - C# - D

Tempo of the track is 130 bpm, entire thing is in 4/4. 

Just a bit more info just in case it helps: 

Instrument Ranges: 
	Bass: 		D3 - A#4		Note: C4
	MainSitar: 	A4 - A#6		Note: C6
	BgSitar: 	A5 - A#6		Note: C6
	DistGtr: 	D5 - A#5		Note: C5

The individual notes have their reverb tails left intact, with the track seamlessly able to loop. I included both the .ogg and the .wav but it's up to you which to use. Enjoy! 